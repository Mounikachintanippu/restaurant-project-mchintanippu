---
title: Cafe Hours
layout: hours.njk
---

# Cafe hours

We are open on all days except federal holidays.
