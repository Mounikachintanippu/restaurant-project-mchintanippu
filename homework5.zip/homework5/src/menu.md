---
title: Cafe Menu
layout: menu.njk
---

# Cafe menu

We prepare all our food from fresh locally sourced produce using our signature recipe passed down in our family from 3 generations.
